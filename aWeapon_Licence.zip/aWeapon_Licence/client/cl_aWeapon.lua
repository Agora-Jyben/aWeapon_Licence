ESX = nil

local PlayerData = {}
local psyreussi
local totalrepok = 0
local totalrepfail = 0
local examppa = 1
local ScoreFinal = 0
local champselect = 0

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}
local societyvigneronmoney = nil

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

local ILplayer = nil

Citizen.CreateThread(function()
    while true do
        ESX.TriggerServerCallback("aWeapon:GetPlayersLicences", function(listPlicence) 
            if listPlicence then
                ILplayer = {}
                for k,v in pairs(listPlicence) do
                    -- print(k, json.encode(v))
                    -- for i=1,k,1 do
                        table.insert(ILplayer,{
                            name = v.nom,
                            prename = v.prenom,
                            dateofbirth = v.dob,
                            id = v.id,
                            pass = v.pass
                        })
                    -- end
                end
            end
        end)
        Citizen.Wait(250)  
    end
end)


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

RegisterNetEvent('esx:setJob2')
AddEventHandler('esx:setJob2', function(job2)
    ESX.PlayerData.job2 = job2
end)


--------------------------------------------------------------------
function testPsyco()
    local presentationpsyco = RageUI.CreateMenu("~r~AMMU-NATION", "~y~Test Psycologique")
    local question1psyco = RageUI.CreateSubMenu(presentationpsyco, "~r~AMMU-NATION", "~o~Question 1")
    local question2psyco = RageUI.CreateSubMenu(question1psyco, "~r~AMMU-NATION", "~o~Question 2")
    local question3psyco = RageUI.CreateSubMenu(question2psyco, "~r~AMMU-NATION", "~o~Question 3")
    local question4psyco = RageUI.CreateSubMenu(question3psyco, "~r~AMMU-NATION", "~o~Question 4")
    local question5psyco = RageUI.CreateSubMenu(question4psyco, "~r~AMMU-NATION", "~o~Question 5")
    presentationpsyco:SetRectangleBanner(0, 0, 0)
    question1psyco:SetRectangleBanner(0, 0, 0)
    question2psyco:SetRectangleBanner(0, 0, 0)
    question3psyco:SetRectangleBanner(0, 0, 0)
    question4psyco:SetRectangleBanner(0, 0, 0)
    question5psyco:SetRectangleBanner(0, 0, 0)

    
    RageUI.Visible(presentationpsyco, not RageUI.Visible(presentationpsyco))
    while presentationpsyco do
        Citizen.Wait(0)
        RageUI.IsVisible(presentationpsyco, true, false, true, function()
            --RageUI.Separator("")

            RageUI.Separator("~y~↓ Description du test psycologique ~y~↓")

            RageUI.ButtonWithStyle("A savoir !","Info : \n- Vous ne devez pas faire plus de 2 fautes pour reussir le test !\n\n- Une fois le test reussi il vous faudras passer l'epreuve pratique !\n\n- Si vous loupez un des deux test vous devrais repasser les deux (psycologique et pratique)\n\nBonne chance à vous !", {RightLabel = "→"}, true, function()
            end)


            RageUI.Separator("~y~↓ ~p~Le questionnaire ~y~↓")

            RageUI.ButtonWithStyle("Commencer le questionnaire", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
            end, question1psyco)

            RageUI.Separator("~y~↓ Resultat de votre test psycologique ~y~↓")

            RageUI.ButtonWithStyle("Voir votre resultat final", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                if (Selected) then
                    if totalrepfail == 0 and totalrepok == 0 then
                        RageUI.Popup{
                            message = "~o~Vous n'avez pas remplis le test psycologique !"
                        }
                    elseif totalrepfail >= 3 and totalrepok <= 3 then
                        RageUI.Popup{
                            message = "~r~Vous n'avez pas reussi le test psycologique !"
                        }
                        TriggerServerEvent("aWeapon_Licence:PlayerLoosePsy")
                        examppa = 0
                        RageUI.CloseAll()
                    elseif totalrepok >= 3 and totalrepfail <= 2 then
                        RageUI.Popup{
                            message = "~g~Vous avez reussi le test psycologique !"
                        }
                        TriggerServerEvent("aWeapon_Licence:accesstandtir")
                    end
                end
            end)

            end, function() 
            end)

            RageUI.IsVisible(question1psyco, true, false, true, function()
                RageUI.Separator(Cweapon_licence.quest.questionun.questone)
                if Cweapon_licence.espace.questionUN then
                    RageUI.Separator("")
                end
                RageUI.ButtonWithStyle(Cweapon_licence.quest.questionun.repquestone, Cweapon_licence.quest.questionun.descrepquestone, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questionun.resultQRone == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question2psyco)

                RageUI.ButtonWithStyle(Cweapon_licence.quest.questionun.repquestdeux, Cweapon_licence.quest.questionun.descrepquestdeux, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questionun.resultQRdeux == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question2psyco)

                RageUI.ButtonWithStyle(Cweapon_licence.quest.questionun.repquesttrois, Cweapon_licence.quest.questionun.descrepquesttrois, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questionun.resultQRtrois == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question2psyco)
                
            end, function() 
            end)

            RageUI.IsVisible(question2psyco, true, false, true, function()
                RageUI.Separator(Cweapon_licence.quest.questiondeux.questtwo)
                if Cweapon_licence.espace.questionDeux then
                    RageUI.Separator("")
                end
                RageUI.ButtonWithStyle(Cweapon_licence.quest.questiondeux.repquesttwo, Cweapon_licence.quest.questiondeux.descrepquesttwo, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questiondeux.resultQRtwo == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question3psyco)

                RageUI.ButtonWithStyle(Cweapon_licence.quest.questiondeux.repquestdeux, Cweapon_licence.quest.questiondeux.descrepquestdeux, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questiondeux.resultQRdeux == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question3psyco)

                RageUI.ButtonWithStyle(Cweapon_licence.quest.questiondeux.repquesttrois, Cweapon_licence.quest.questiondeux.descrepquesttrois, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questiondeux.resultQRtrois == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question3psyco)
                
            end, function() 
            end)

            RageUI.IsVisible(question3psyco, true, false, true, function()
                RageUI.Separator(Cweapon_licence.quest.questiontrois.questthree)
                if Cweapon_licence.espace.questionTrois then
                    RageUI.Separator("")
                end
                RageUI.ButtonWithStyle(Cweapon_licence.quest.questiontrois.repquestthree, Cweapon_licence.quest.questiontrois.descrepquestthree, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questiontrois.resultQRthree == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question4psyco)

                RageUI.ButtonWithStyle(Cweapon_licence.quest.questiontrois.repquestdeux, Cweapon_licence.quest.questiontrois.descrepquestdeux, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questiontrois.resultQRdeux == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question4psyco)

                RageUI.ButtonWithStyle(Cweapon_licence.quest.questiontrois.repquesttrois, Cweapon_licence.quest.questiontrois.descrepquesttrois, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questiontrois.resultQRtrois == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question4psyco)
                
            end, function() 
            end)

            RageUI.IsVisible(question4psyco, true, false, true, function()
                RageUI.Separator(Cweapon_licence.quest.questionquatre.questfour)
                if Cweapon_licence.espace.questionQuatre then
                    RageUI.Separator("")
                end
                RageUI.ButtonWithStyle(Cweapon_licence.quest.questionquatre.repquestfour, Cweapon_licence.quest.questionquatre.descrepquestfour, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questionquatre.resultQRfour == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question5psyco)

                RageUI.ButtonWithStyle(Cweapon_licence.quest.questionquatre.repquestdeux, Cweapon_licence.quest.questionquatre.descrepquestdeux, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questionquatre.resultQRdeux == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question5psyco)

                RageUI.ButtonWithStyle(Cweapon_licence.quest.questionquatre.repquesttrois, Cweapon_licence.quest.questionquatre.descrepquesttrois, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questionquatre.resultQRrois == true then
                            totalrepok = totalrepok +1
                        else
                            totalrepfail = totalrepfail +1
                        end
                    end 
                end, question5psyco)
                
            end, function() 
            end)

            RageUI.IsVisible(question5psyco, true, false, true, function()
                RageUI.Separator(Cweapon_licence.quest.questioncinq.questfive)
                if Cweapon_licence.espace.questionCinq then
                    RageUI.Separator("")
                end
                RageUI.ButtonWithStyle(Cweapon_licence.quest.questioncinq.repquestfive, Cweapon_licence.quest.questioncinq.descrepquestfive, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questioncinq.resultQRfive == true then
                            totalrepok = totalrepok +1
                            RageUI.Popup{
                                message = "~g~Vous avez terminer le test psycologique, allez voir votre resultat !"
                            }
                        else
                            totalrepfail = totalrepfail +1
                            RageUI.Popup{
                                message = "~g~Vous avez terminer le test psycologique, allez voir votre resultat !"
                            }
                        end
                    end 
                end, presentationpsyco)

                RageUI.ButtonWithStyle(Cweapon_licence.quest.questioncinq.repquestdeux, Cweapon_licence.quest.questioncinq.descrepquestdeux, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questioncinq.resultQRdeux == true then
                            totalrepok = totalrepok +1
                            RageUI.Popup{
                                message = "~g~Vous avez terminer le test psycologique, allez voir votre resultat !"
                            }
                        else
                            totalrepfail = totalrepfail +1
                            RageUI.Popup{
                                message = "~g~Vous avez terminer le test psycologique, allez voir votre resultat !"
                            }
                        end
                    end 
                end, presentationpsyco)

                RageUI.ButtonWithStyle(Cweapon_licence.quest.questioncinq.repquesttrois, Cweapon_licence.quest.questioncinq.descrepquesttrois, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        if Cweapon_licence.quest.questioncinq.resultQRtrois == true then
                            totalrepok = totalrepok +1
                            RageUI.Popup{
                                message = "~g~Vous avez terminer le test psycologique, allez voir votre resultat !"
                            }
                        else
                            totalrepfail = totalrepfail +1
                            RageUI.Popup{
                                message = "~g~Vous avez terminer le test psycologique, allez voir votre resultat !"
                            }
                        end
                    end 
                end, presentationpsyco)
                
            end, function() 
            end)

        if not RageUI.Visible(presentationpsyco) and not RageUI.Visible(question1psyco) and not RageUI.Visible(question2psyco) and not RageUI.Visible(question3psyco) and not RageUI.Visible(question4psyco) and not RageUI.Visible(question5psyco) then
            presentationpsyco = RMenu:DeleteType("presentationpsyco", true)
        end
    end
end

local Tpasser = false
local ppaTir = false
local nbManche = 0
local okMenuOpen = false
--------------------------------------------------------------------
function MenuStandTir()
    local Menustandtir = RageUI.CreateMenu("~r~AMMU-NATION", "~y~Stand de Tir")
    local rangTrain = RageUI.CreateSubMenu(Menustandtir, "~r~AMMU-NATION", "~b~Champ de tir")
    Menustandtir:SetRectangleBanner(0, 0, 0)
    rangTrain:SetRectangleBanner(0, 0, 0)
    
    RageUI.Visible(Menustandtir, not RageUI.Visible(Menustandtir))
    while Menustandtir do
        Citizen.Wait(0)
        RageUI.IsVisible(Menustandtir, true, false, true, function()
            RageUI.Separator("~y~↓ ~p~Le PPA ~y~↓")

            RageUI.ButtonWithStyle("A savoir !","Info : \n- Vous devez faire 5 point pour reussir le test !\n\n- Les cibles à tuer sont équiper d'une cagoule !\n\n- Si vous loupez ce test vous devrais repasser les deux (psycologique et pratique)\n\nBonne chance à vous !", {RightLabel = "→"}, true, function()
            end)

            RageUI.ButtonWithStyle("Commencer le test de tir pour le PPA", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                if (Selected) then
                    if ppaTir == false then
                        TriggerServerEvent("aweapon_licence:tchektestpsyco")
                        ppaTir = true
                        RageUI.CloseAll()
                    elseif ppaTir == true then
                        RageUI.Popup{
                            message = "~y~Vous avez déjà reussi votre test !"
                        }
                    end
                end
            end)
            

            RageUI.ButtonWithStyle("Voir votre résultat du Test Tir", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                if (Selected) then
                    if Tpasser == true or ppaTir == true then
                        RageUI.Popup{
                            message = "~y~Votre résultat est de [ ~g~"..ScoreFinal.."/5~y~ ] !"
                        }
                        if ScoreFinal == 5 then
                            TriggerServerEvent("aWeapon_Licence:givelicence")
                            RageUI.Popup{
                                message = "~g~Félicitation vous avez reussi votre PPA !"
                            }
                            Wait(500)
                            RageUI.Popup{
                                message = "~g~Vous détenez désormais le ~b~PPA !"
                            }
                        elseif ScoreFinal < 5 then
                            RageUI.Popup{
                                message = "~r~Vous avez rater votre test !\n~y~Vous avez louper des cibles !"
                            }
                            TriggerServerEvent("aWeapon_Licence:PlayerLooseTir")
                            Tpasser = false
                        elseif ScoreFinal > 5 then
                            RageUI.Popup{
                                message = "~r~Vous avez rater votre test !\n~y~Vous avez tirer sur trop de cibles !"
                            }
                            TriggerServerEvent("aWeapon_Licence:PlayerLooseTir")
                            Tpasser = false
                        end
                    else
                        RageUI.Popup{
                            message = "~r~Vous n'avez pas encore passer votre test !"
                        }
                    end
                end
            end)

            RageUI.Separator("~y~↓ ~p~Stand de Tir ~y~↓")

            RageUI.ButtonWithStyle("Commencer une séance d'entrainement", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                if (Selected) then
                end
            end, rangTrain)

            RageUI.Separator("~p~↓ ~g~Score : "..ScoreFinal.."~r~ / ~g~Nombre de manche(s) : "..nbManche.." ~p~↓")

            RageUI.ButtonWithStyle("Reset votre score", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                if (Selected) then
                    ScoreFinal = 0
                    nbManche = 0
                end
            end)

            end, function() 
            end)

            RageUI.IsVisible(rangTrain, true, false, true, function()
                RageUI.Separator("Choix du champ de tir\n6 cible par seance")
                RageUI.Separator("")

                RageUI.ButtonWithStyle("Champ 1", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                    if (Selected) then
                        RageUI.Popup{
                            message = "~b~Vous avez ~r~5 sec ~b~avant que la séance ne commence.\n~r~Preparez-vous !"
                        }
                        champselect = 1
                        nbManche = nbManche+1
                        Wait(Cweapon_licence.StartSeance)
                        SeanceLancer(champselect)
                    end
                end)

                RageUI.ButtonWithStyle("Champ 2", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                    if (Selected) then
                        RageUI.Popup{
                            message = "~b~Vous avez ~r~5 sec ~b~avant que la séance ne commence.\n~r~Preparez-vous !"
                        }
                        nbManche = nbManche+1
                        champselect = 2
                        Wait(Cweapon_licence.StartSeance)
                        SeanceLancer(champselect)
                    end
                end)

                RageUI.ButtonWithStyle("Champ 3", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                    if (Selected) then
                        RageUI.Popup{
                            message = "~b~Vous avez ~r~5 sec ~b~avant que la séance ne commence.\n~r~Preparez-vous !"
                        }
                        nbManche = nbManche+1
                        champselect = 3
                        Wait(Cweapon_licence.StartSeance)
                        SeanceLancer(champselect)
                    end
                end)

                RageUI.ButtonWithStyle("Champ 4", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                    if (Selected) then
                        RageUI.Popup{
                            message = "~b~Vous avez ~r~5 sec ~b~avant que la séance ne commence.\n~r~Preparez-vous !"
                        }
                        nbManche = nbManche+1
                        champselect = 4
                        Wait(Cweapon_licence.StartSeance)
                        SeanceLancer(champselect)
                    end
                end)
            
            end, function() 
            end)

        if not RageUI.Visible(Menustandtir) and not RageUI.Visible(rangTrain)  then
            Menustandtir = RMenu:DeleteType("Menustandtir", true)
            rangTrain = RMenu:DeleteType("rangTrain", true)
        end
    end
end

AddEventHandler("aweapon_licence:lancementppatir")
RegisterNetEvent("aweapon_licence:lancementppatir",function()
    TestTirLancer()
end)

AddEventHandler("aWeapon_Licence:PlayerPsyAccessOk")
RegisterNetEvent("aWeapon_Licence:PlayerPsyAccessOk",function()
    testPsyco()
end)

local OpenMenuPayePPA = false
Citizen.CreateThread(function()
        while true do
            local Timer = 500
            local joueurs = GetEntityCoords(GetPlayerPed(-1), false)
            local distancepsyco = Vdist(joueurs.x, joueurs.y, joueurs.z, Cweapon_licence.pos.testpsyco.position.x, Cweapon_licence.pos.testpsyco.position.y, Cweapon_licence.pos.testpsyco.position.z)
            local Jplayer = GetPlayerPed(-1)
            if distancepsyco <= 5.0 and Cweapon_licence.jeveuxmarker then
                Timer = 0
                DrawMarker(20, Cweapon_licence.pos.testpsyco.position.x, Cweapon_licence.pos.testpsyco.position.y, Cweapon_licence.pos.testpsyco.position.z-1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
                if distancepsyco <= 1.0 then
                    --Timer = 0
                    RageUI.Text({ message = "~r~[E]~s~ pour accéder au test psycologique", time_display = 1 })
                    if IsControlJustPressed(1,51) then
                        if examppa < 1 then
                            RageUI.Popup{
                                message = "Vous avez déjà essayer de passer le test psycologique, revenez demain !"
                            }
                        else
                            TriggerServerEvent("aWeapon_Licence:PlayerPsyAccess")
                        end
                    end   
                end
            end 

            local distancetirtest = Vdist(joueurs.x, joueurs.y, joueurs.z, Cweapon_licence.pos.testtir.position.x, Cweapon_licence.pos.testtir.position.y, Cweapon_licence.pos.testtir.position.z)
            if distancetirtest <= 5.0 and Cweapon_licence.jeveuxmarker then
                Timer = 0
                DrawMarker(20, Cweapon_licence.pos.testtir.position.x, Cweapon_licence.pos.testtir.position.y, Cweapon_licence.pos.testtir.position.z-1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
                if distancetirtest <= 1.0 then
                    RageUI.Text({ message = "~r~[E]~s~ pour intéragir avec l'instructeur", time_display = 1 })
                    if IsControlJustPressed(1,51) then
                        MenuStandTir()
                    end   
                end
            end 

            local distanceaccPPA = Vdist(joueurs.x, joueurs.y, joueurs.z, Cweapon_licence.pos.acceuilPPA.position.x, Cweapon_licence.pos.acceuilPPA.position.y, Cweapon_licence.pos.acceuilPPA.position.z)
            if distanceaccPPA <= 1.5 then
                Timer = 0
                RageUI.Text({ message = "~r~[E]~s~ pour intéragir avec le gérant", time_display = 1 })
                if IsControlJustPressed(1,51) then
                    local messacceuil = 0
                    local textmess

                    RageUI.Text({ message = Cweapon_licence.interaction.acceuil[1]})
                    Wait(2500) -- temps entre chaque phrases 
                    RageUI.Text({ message = Cweapon_licence.interaction.acceuil[2]})
                    Wait(2500) -- temps entre chaque phrases 
                    RageUI.Text({ message = Cweapon_licence.interaction.acceuil[3]})
                    Wait(2500) -- temps entre chaque phrases 
                    RageUI.Text({ message = Cweapon_licence.interaction.acceuil[4]})
                    Wait(2500) -- temps entre chaque phrases 
                    RageUI.Text({ message = Cweapon_licence.interaction.acceuil[5]})
                    Wait(2500) -- temps entre chaque phrases 
                    RageUI.Text({ message = Cweapon_licence.interaction.acceuil[6]})
                    Wait(2500) -- temps entre chaque phrases 
                    RageUI.Text({ message = Cweapon_licence.interaction.acceuil[7]})
                    Wait(1500) -- temps entre chaque phrases 
                    RageUI.Text({ message = Cweapon_licence.interaction.acceuil[8]})
                    Wait(1500) 
                    MenuPayePPA()
                end   
            end 

            
            local infoperm = nil
            local Jname = nil
            local distanceaccLSPD = Vdist(joueurs.x, joueurs.y, joueurs.z, Cweapon_licence.pos.accesLSPD.position.x, Cweapon_licence.pos.accesLSPD.position.y, Cweapon_licence.pos.accesLSPD.position.z)
            if distanceaccLSPD <= 5.0 and Cweapon_licence.jeveuxmarker then
                Timer = 0
                DrawMarker(20, Cweapon_licence.pos.accesLSPD.position.x, Cweapon_licence.pos.accesLSPD.position.y, Cweapon_licence.pos.accesLSPD.position.z-1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
                if distanceaccLSPD <= 1.0 then
                    RageUI.Text({ message = "~r~[E]~s~ pour acceder au archives", time_display = 1 })
                    if IsControlJustPressed(1,51) then
                        local Pname 
                        local grade = ESX.PlayerData.job.grade_name
                        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' and ESX.PlayerData.job.grade_name == 'boss' or ESX.PlayerData.job2 and ESX.PlayerData.job2.name == 'police' and ESX.PlayerData.job2.grade_name == 'boss' then
                        
                            -- OpenArchive()
                            MenuArchive(grade)
                            
                            
                        else
                            RageUI.Popup{
                                message = "Vous n'avez pas la permission d'acceder au archives"
                            }
                        end
                    end   
                end
            end 
        Citizen.Wait(Timer)   
    end
end)

-- local ILplayer = nil
local name = nil
local identifier = nil 
local passJ 

MenuArchive = function(grade)

    titleLSPD = Cweapon_licence.interaction.bouton.MenuLSPD.Titre
    subtitleLSPD = Cweapon_licence.interaction.bouton.MenuLSPD.sublabel
    separatorLSPD = Cweapon_licence.interaction.bouton.MenuLSPD.separatorLSPD
    separatorVPPA = Cweapon_licence.interaction.bouton.MenuLSPD.separatorVPPA
    ButtonOneLSPD = Cweapon_licence.interaction.bouton.MenuLSPD.ButtonOne
    ButtonTwoLSPD = Cweapon_licence.interaction.bouton.MenuLSPD.ButtonTwo

    local MenuAchiveOpen = RageUI.CreateMenu(titleLSPD, subtitleLSPD)
    MenuAchiveOpen:SetRectangleBanner(0, 0, 0)

    local MenuChoix = RageUI.CreateMenu(titleLSPD, "~b~Archives")
    MenuChoix:SetRectangleBanner(0, 0, 0)
    
    RageUI.Visible(MenuAchiveOpen, not RageUI.Visible(MenuAchiveOpen))
    while MenuAchiveOpen do
        Citizen.Wait(0)
        
        RageUI.IsVisible(MenuAchiveOpen, true, false, true, function()

            RageUI.Separator(separatorLSPD.." "..grade.."\nVoici la liste des personnes détenant le ~b~PPA")
            RageUI.Separator()

            for k,v in pairs(ILplayer) do
                local passJ = ""
                if v.pass == "0" then
                    passJ = "~g~actif"
                elseif v.pass == "1" then
                    passJ = "~r~ retirer"
                end

                RageUI.ButtonWithStyle("~g~Nom : ~s~"..v.name.." ~r~/ ~g~Prenom : ~s~"..v.prename.." ~r~/~b~acces PPA : "..passJ, "Liste d'action possible sur le dossier : ~r~"..v.name, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                    if (Selected) then
                        -- print("Acces refuser pour : "..v.name)
                        identifier = v.id
                        name = v.name
                    end
                end,MenuChoix)
            end
        end, function() 
        end)

        RageUI.IsVisible(MenuChoix, true, false, true, function()
            RageUI.ButtonWithStyle("Annulé le ~b~PPA~s~ de ~r~"..name, "~r~ATTENTION si vous annulez le ppa à cette personne par cette ordinateur et que cette personne était interdit d'acces au test alors cette personne auras à nouveau le droit d'acces au test ppa !!", {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                if (Selected) then
                    -- print("PPA retirer pour : "..name)
                    TriggerServerEvent("aWeapon_Licence:deletelicence",identifier)
                end
            end)

            RageUI.ButtonWithStyle("Retirer l'acces au test ~b~PPA~s~ à ~r~"..name, nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                if (Selected) then
                    -- print("Acces refuser pour : "..name)
                    TriggerServerEvent("aWeapon_Licence:antipass",identifier)
                end
            end)

            RageUI.Separator()

            RageUI.ButtonWithStyle("Redonner l'acces au test ~b~PPA~s~ à ~r~"..name, nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                if (Selected) then
                    -- print("Acces refuser pour : "..name)
                    TriggerServerEvent("aWeapon_Licence:deleteantipass",identifier)
                end
            end)

        end, function() 
        end)

        if not RageUI.Visible(MenuAchiveOpen) and not RageUI.Visible(MenuChoix) then
            MenuAchiveOpen = RMenu:DeleteType("MenuAchiveOpen", true)
            MenuChoix = RMenu:DeleteType("MenuChoix", true)
        end
    end
end

RegisterNetEvent('aWeapon_Licence:okpass')
AddEventHandler('aWeapon_Licence:okpass', function(source)
	RageUI.Text({ message = Cweapon_licence.interaction.acceuil[9]})
    Wait(3500)
    RageUI.Text({ message = Cweapon_licence.interaction.acceuil[10]})
end)

MenuPayePPA = function(okMenuOpen)
    okMenuOpen = false
    title = Cweapon_licence.interaction.bouton.Menu.Titre
    subtitle = Cweapon_licence.interaction.bouton.Menu.sublabel
    separatorUn = Cweapon_licence.interaction.bouton.Menu.sblUn_separator
    reponseUn = Cweapon_licence.interaction.bouton.Menu.repUn
    reponseDeux = Cweapon_licence.interaction.bouton.Menu.repDeux
    local MenuAcceuil = RageUI.CreateMenu(title, subtitle)
    MenuAcceuil:SetRectangleBanner(0, 0, 0)
    
    RageUI.Visible(MenuAcceuil, not RageUI.Visible(MenuAcceuil))
    while MenuAcceuil do
        Citizen.Wait(0)
        RageUI.IsVisible(MenuAcceuil, true, false, true, function()

            RageUI.Separator(separatorUn)

            RageUI.ButtonWithStyle(reponseUn, nil, {RightLabel = "~g~"..Cweapon_licence.price.." $"}, true, function(Hovered,Active,Selected)
                if (Selected) then
                    print("PPA Payer")
                    TriggerServerEvent("aWeapon_Licence:PlayerPayAccess")
                    -- PayPPa()
                    
                    RageUI.CloseAll()
                end
            end)

            RageUI.ButtonWithStyle(reponseDeux, nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                if (Selected) then
                    RageUI.Text({ message = Cweapon_licence.interaction.acceuil[9]})
                    Wait(3500)
                    RageUI.Text({ message = Cweapon_licence.interaction.acceuil[10]})
                    Wait(3500)
                    RageUI.CloseAll()
                end
            end)

            end, function() 
            end)

        if not RageUI.Visible(MenuAcceuil) then
            MenuAcceuil = RMenu:DeleteType("MenuAcceuil", true)
        end
    end
end
    
PayPPa = function(source)
    print('client 1')
    ESX.TriggerServerCallback("aWeapon:GetPassAccess", function(pass) 
        if pass then
            TriggerServerEvent("aWeapon_Licence:PlayerPayAccess", source)
        end
    end)
end

SeanceLancer = function(champselect)
    local pedtrainun = GetHashKey("hc_gunman")
    local posfinal = Cweapon_licence.pos.pedtirppa
    local i = champselect
    print(i)
    for k,v in pairs(posfinal[i]) do
        print(k)
        while not HasModelLoaded(pedtrainun) do
            RequestModel(pedtrainun)
            Wait(20)
        end
        trainun = CreatePed("PED_TYPE_CIVFEMALE", "hc_gunman", v.x, v.y, v.z, v.h, false, true)
        SetBlockingOfNonTemporaryEvents(trainun, true)
        FreezeEntityPosition(trainun, true)
        TaskStartScenarioInPlace(trainun, 'WORLD_HUMAN_DRUG_DEALER_HARD', 0, false)
        --GiveWeaponToPed(pedtesttirneuf, 0x9D61E50F --[[hash de l'arme : https://wiki.rage.mp/index.php?title=Weapons]], 0, true --[[arme en main]], true --[[arme en main]]) --donne une arme au ped

        Wait(3000)

        TrainPoint(trainun)
    end
    MenuStandTir()
end


TrainPoint = function(ped)
    if IsEntityDead(ped) then
        DeleteEntity(ped)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(ped)
    end
end

TestTirLancer = function()

    TriggerServerEvent("aWeapon_Licence:GiveWeaponTest")

    local hashtirun = GetHashKey("a_f_y_beach_01")
    while not HasModelLoaded(hashtirun) do
        RequestModel(hashtirun)
        Wait(20)
    end
    pedtesttirun = CreatePed("PED_TYPE_CIVFEMALE", "a_f_y_beach_01", Cweapon_licence.pos.pedtirppa[4].positionUn.x, Cweapon_licence.pos.pedtirppa[4].positionUn.y, Cweapon_licence.pos.pedtirppa[4].positionUn.z, Cweapon_licence.pos.pedtirppa[4].positionUn.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttirun, true)
    FreezeEntityPosition(pedtesttirun, true)
    TaskStartScenarioInPlace(pedtesttirun, 'WORLD_HUMAN_AA_COFFEE', 0, false)

    Wait(3500)
    
    if IsEntityDead(pedtesttirun) then
        DeleteEntity(pedtesttirun)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttirun)
    end

    local hashtirdeux = GetHashKey("hc_gunman")
    while not HasModelLoaded(hashtirdeux) do
        RequestModel(hashtirdeux)
        Wait(20)
    end
    pedtesttirdeux = CreatePed("PED_TYPE_CIVFEMALE", "hc_gunman", Cweapon_licence.pos.pedtirppa[4].positionDeux.x, Cweapon_licence.pos.pedtirppa[4].positionDeux.y, Cweapon_licence.pos.pedtirppa[4].positionDeux.z, Cweapon_licence.pos.pedtirppa[4].positionDeux.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttirdeux, true)
    FreezeEntityPosition(pedtesttirdeux, true)
    TaskStartScenarioInPlace(pedtesttirdeux, 'WORLD_HUMAN_DRUG_DEALER_HARD', 0, false)

    Wait(3500)

    if IsEntityDead(pedtesttirdeux) then
        DeleteEntity(pedtesttirdeux)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttirdeux)
    end

    local hashtirtrois = GetHashKey("hc_gunman")
    while not HasModelLoaded(hashtirtrois) do
        RequestModel(hashtirtrois)
        Wait(20)
    end
    pedtesttirtrois = CreatePed("PED_TYPE_CIVFEMALE", "hc_gunman", Cweapon_licence.pos.pedtirppa[4].positionTrois.x, Cweapon_licence.pos.pedtirppa[4].positionTrois.y, Cweapon_licence.pos.pedtirppa[4].positionTrois.z, Cweapon_licence.pos.pedtirppa[4].positionTrois.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttirtrois, true)
    FreezeEntityPosition(pedtesttirtrois, true)
    TaskStartScenarioInPlace(pedtesttirtrois, 'WORLD_HUMAN_DRUG_DEALER_HARD', 0, false)
    --GiveWeaponToPed(pedtesttirtrois, 0x9D61E50F --[[hash de l'arme : https://wiki.rage.mp/index.php?title=Weapons]], 0, true --[[arme en main]], true --[[arme en main]]) --donne une arme au ped

    Wait(3500)

    if IsEntityDead(pedtesttirtrois) then
        DeleteEntity(pedtesttirtrois)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttirtrois)
    end


    local hashtirquatre = GetHashKey("s_m_m_snowcop_01")
    while not HasModelLoaded(hashtirquatre) do
        RequestModel(hashtirquatre)
        Wait(20)
    end
    pedtesttirquatre = CreatePed("PED_TYPE_CIVFEMALE", "s_m_m_snowcop_01", Cweapon_licence.pos.pedtirppa[4].positionQuatre.x, Cweapon_licence.pos.pedtirppa[4].positionQuatre.y, Cweapon_licence.pos.pedtirppa[4].positionQuatre.z, Cweapon_licence.pos.pedtirppa[4].positionQuatre.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttirquatre, true)
    FreezeEntityPosition(pedtesttirquatre, true)
    TaskStartScenarioInPlace(pedtesttirquatre, 'WORLD_HUMAN_STAND_FIRE', 0, false)

    Wait(3500)

    if IsEntityDead(pedtesttirquatre) then
        DeleteEntity(pedtesttirquatre)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttirquatre)
    end



    local hashtircinq = GetHashKey("hc_gunman")
    while not HasModelLoaded(hashtircinq) do
        RequestModel(hashtircinq)
        Wait(20)
    end
    pedtesttircinq = CreatePed("PED_TYPE_CIVFEMALE", "hc_gunman", Cweapon_licence.pos.pedtirppa[4].positionCinq.x, Cweapon_licence.pos.pedtirppa[4].positionCinq.y, Cweapon_licence.pos.pedtirppa[4].positionCinq.z, Cweapon_licence.pos.pedtirppa[4].positionCinq.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttircinq, true)
    FreezeEntityPosition(pedtesttircinq, true)
    TaskStartScenarioInPlace(pedtesttircinq, 'WORLD_HUMAN_DRUG_DEALER_HARD', 0, false)
    --GiveWeaponToPed(pedtesttircinq, 0x9D61E50F --[[hash de l'arme : https://wiki.rage.mp/index.php?title=Weapons]], 0, true --[[arme en main]], true --[[arme en main]]) --donne une arme au ped

    Wait(3500)

    if IsEntityDead(pedtesttircinq) then
        DeleteEntity(pedtesttircinq)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttircinq)
    end


    local hashtirsix = GetHashKey("a_f_y_clubcust_04")
    while not HasModelLoaded(hashtirsix) do
        RequestModel(hashtirsix)
        Wait(20)
    end
    pedtesttirsix = CreatePed("PED_TYPE_CIVFEMALE", "a_f_y_clubcust_04", Cweapon_licence.pos.pedtirppa[4].positionSix.x, Cweapon_licence.pos.pedtirppa[4].positionSix.y, Cweapon_licence.pos.pedtirppa[4].positionSix.z, Cweapon_licence.pos.pedtirppa[4].positionSix.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttirsix, true)
    FreezeEntityPosition(pedtesttirsix, true)
    TaskStartScenarioInPlace(pedtesttirsix, 'WORLD_HUMAN_AA_SMOKE', 0, false)

    Wait(3500)

    if IsEntityDead(pedtesttirsix) then
        DeleteEntity(pedtesttirsix)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttirsix)
    end


    local hashtirsept = GetHashKey("mp_m_securoguard_01")
    while not HasModelLoaded(hashtirsept) do
        RequestModel(hashtirsept)
        Wait(20)
    end
    pedtesttirsept = CreatePed("PED_TYPE_CIVFEMALE", "mp_m_securoguard_01", Cweapon_licence.pos.pedtirppa[4].positionUn.x, Cweapon_licence.pos.pedtirppa[4].positionUn.y, Cweapon_licence.pos.pedtirppa[4].positionUn.z, Cweapon_licence.pos.pedtirppa[4].positionUn.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttirsept, true)
    FreezeEntityPosition(pedtesttirsept, true)
    TaskStartScenarioInPlace(pedtesttirsept, 'WORLD_HUMAN_CLIPBOARD', 0, false)

    Wait(3500)

    if IsEntityDead(pedtesttirsept) then
        DeleteEntity(pedtesttirsept)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttirsept)
    end


    local hashtirhuit = GetHashKey("mp_m_bogdangoon")
    while not HasModelLoaded(hashtirhuit) do
        RequestModel(hashtirhuit)
        Wait(20)
    end
    pedtesttirhuit = CreatePed("PED_TYPE_CIVFEMALE", "mp_m_bogdangoon", Cweapon_licence.pos.pedtirppa[4].positionDeux.x, Cweapon_licence.pos.pedtirppa[4].positionDeux.y, Cweapon_licence.pos.pedtirppa[4].positionDeux.z, Cweapon_licence.pos.pedtirppa[4].positionDeux.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttirhuit, true)
    FreezeEntityPosition(pedtesttirhuit, true)
    TaskStartScenarioInPlace(pedtesttirhuit, 'WORLD_HUMAN_DRUG_DEALER_HARD', 0, false)
    --GiveWeaponToPed(pedtesttirhuit, 0x9D61E50F --[[hash de l'arme : https://wiki.rage.mp/index.php?title=Weapons]], 0, true --[[arme en main]], true --[[arme en main]]) --donne une arme au ped

    Wait(3500)

    if IsEntityDead(pedtesttirhuit) then
        DeleteEntity(pedtesttirhuit)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttirhuit)
    end


    local hashtirneuf = GetHashKey("hc_gunman")
    while not HasModelLoaded(hashtirneuf) do
        RequestModel(hashtirneuf)
        Wait(20)
    end
    pedtesttirneuf = CreatePed("PED_TYPE_CIVFEMALE", "hc_gunman", Cweapon_licence.pos.pedtirppa[4].positionTrois.x, Cweapon_licence.pos.pedtirppa[4].positionTrois.y, Cweapon_licence.pos.pedtirppa[4].positionTrois.z, Cweapon_licence.pos.pedtirppa[4].positionTrois.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttirneuf, true)
    FreezeEntityPosition(pedtesttirneuf, true)
    TaskStartScenarioInPlace(pedtesttirneuf, 'WORLD_HUMAN_DRUG_DEALER_HARD', 0, false)
    --GiveWeaponToPed(pedtesttirneuf, 0x9D61E50F --[[hash de l'arme : https://wiki.rage.mp/index.php?title=Weapons]], 0, true --[[arme en main]], true --[[arme en main]]) --donne une arme au ped

    Wait(3500)

    if IsEntityDead(pedtesttirneuf) then
        DeleteEntity(pedtesttirneuf)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttirneuf)
    end

    local hashtirdix = GetHashKey("s_m_m_snowcop_01")
    while not HasModelLoaded(hashtirdix) do
        RequestModel(hashtirdix)
        Wait(20)
    end
    pedtesttirdix = CreatePed("PED_TYPE_CIVFEMALE", "s_m_m_snowcop_01", Cweapon_licence.pos.pedtirppa[4].positionQuatre.x, Cweapon_licence.pos.pedtirppa[4].positionQuatre.y, Cweapon_licence.pos.pedtirppa[4].positionQuatre.z, Cweapon_licence.pos.pedtirppa[4].positionQuatre.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttirdix, true)
    FreezeEntityPosition(pedtesttirdix, true)
    TaskStartScenarioInPlace(pedtesttirdix, 'WORLD_HUMAN_STAND_FIRE', 0, false)

    Wait(3500)

    if IsEntityDead(pedtesttirdix) then
        DeleteEntity(pedtesttirdix)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttirdix)
    end


    local hashtironze = GetHashKey("a_f_y_beach_01")
    while not HasModelLoaded(hashtironze) do
        RequestModel(hashtironze)
        Wait(20)
    end
    pedtesttironze = CreatePed("PED_TYPE_CIVFEMALE", "a_f_y_beach_01", Cweapon_licence.pos.pedtirppa[4].positionCinq.x, Cweapon_licence.pos.pedtirppa[4].positionCinq.y, Cweapon_licence.pos.pedtirppa[4].positionCinq.z, Cweapon_licence.pos.pedtirppa[4].positionCinq.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttironze, true)
    FreezeEntityPosition(pedtesttironze, true)
    TaskStartScenarioInPlace(pedtesttironze, 'WORLD_HUMAN_AA_COFFEE', 0, false)

    Wait(3500)
    
    if IsEntityDead(pedtesttironze) then
        DeleteEntity(pedtesttironze)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttironze)
    end


    local hashtirdouze = GetHashKey("a_f_y_clubcust_04")
    while not HasModelLoaded(hashtirdouze) do
        RequestModel(hashtirdouze)
        Wait(20)
    end
    pedtesttirdouze = CreatePed("PED_TYPE_CIVFEMALE", "a_f_y_clubcust_04", Cweapon_licence.pos.pedtirppa[4].positionSix.x, Cweapon_licence.pos.pedtirppa[4].positionSix.y, Cweapon_licence.pos.pedtirppa[4].positionSix.z, Cweapon_licence.pos.pedtirppa[4].positionSix.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttirdouze, true)
    FreezeEntityPosition(pedtesttirdouze, true)
    TaskStartScenarioInPlace(pedtesttirdouze, 'WORLD_HUMAN_AA_SMOKE', 0, false)

    Wait(3500)

    if IsEntityDead(pedtesttirdouze) then
        DeleteEntity(pedtesttirdouze)
        ScoreFinal = ScoreFinal + 1
    else
        DeleteEntity(pedtesttirdouze)
    end

    TriggerServerEvent("aWeapon_Licence:RemoveWeaponTest")

    RageUI.Popup{
        message = "~r~[~g~Test Tir terminer !~r~]\n~y~Demandez votre résultat au Sergent !"
    }

end

Citizen.CreateThread(function()
    local hash = GetHashKey("csb_mjo")
    while not HasModelLoaded(hash) do
        RequestModel(hash)
        Wait(20)
    end
    pedacceuilppa = CreatePed("PED_TYPE_CIVFEMALE", "csb_mjo", 20.71, -1104.83, 28.8, 158.5, false, true)
    SetBlockingOfNonTemporaryEvents(pedacceuilppa, true)
    FreezeEntityPosition(pedacceuilppa, true)
    SetEntityInvincible(pedacceuilppa, true)
    TaskStartScenarioInPlace(pedacceuilppa, 'WORLD_HUMAN_CLIPBOARD', 0, false)

    local hashtesttir = GetHashKey("s_m_y_armymech_01")
    while not HasModelLoaded(hashtesttir) do
        RequestModel(hashtesttir)
        Wait(20)
    end

    pedtesttir = CreatePed("PED_TYPE_CIVFEMALE", "s_m_y_armymech_01", 15.57, -1098.89, 28.8, 66.82, false, true)
    SetBlockingOfNonTemporaryEvents(pedtesttir, true)
    FreezeEntityPosition(pedtesttir, true)
    SetEntityInvincible(pedtesttir, true)
    TaskStartScenarioInPlace(pedtesttir, 'WORLD_HUMAN_GUARD_STAND_ARMY', 0, false)

    local hashtestpsyco = GetHashKey("a_f_y_femaleagent")
    while not HasModelLoaded(hashtestpsyco) do
        RequestModel(hashtestpsyco)
        Wait(20)
    end

    pedtestpsyco = CreatePed("PED_TYPE_CIVFEMALE", "a_f_y_femaleagent", 15.72, -1108.42, 28.8, 80.16, false, true)
    SetBlockingOfNonTemporaryEvents(pedtestpsyco, true)
    FreezeEntityPosition(pedtestpsyco, true)
    SetEntityInvincible(pedtestpsyco, true)
    TaskStartScenarioInPlace(pedtestpsyco, 'WORLD_HUMAN_CLIPBOARD', 0, false)
end)