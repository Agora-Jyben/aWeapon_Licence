
Cweapon_licence = {}

Cweapon_licence.useWeaponItem = true --- true = Oui (vous utilisez les armes en item) | false = Non  (vous n'utilisez pas les armes en item)
Cweapon_licence.jeveuxmarker = true --- true = Oui | false = Non (afficher les markers)
Cweapon_licence.jeveuxblips = true --- true = Oui | false = Non (afficher les blips)

Cweapon_licence.webhook = {
	onPPA = "https://discord.com/api/webhooks/927863140648116244/KQ0JtQHxWUNiSTs7zJnh_L5DhyMQVaiocn4OP-hPURUY1ZvgZCfhqr_tu2n3Z2_hpJkZ" -- Lien de votre webhook
}

Cweapon_licence.price = 25000 -- prix du droit de passage des test du ppa
Cweapon_licence.StartSeance = 5000 -- temps d'attente avant de lancer la séance d'entrainement sur le champ selectionner


-- Nom des Items utilisé 
Cweapon_licence.Item = {
	weaponName = "combatpistol", -- Nom de l'arme en item, CHANGER LE NOM SI VOUS UTILISEZ PAS LES ARMES EN ITEMS par ceci : "weapon_combatpistol"
	bulletName = "pistol_ammo", -- Nom des balles en items
	bulletNumber = 12, -- Nombre de balle donner pour passer le test pratique
	paiementPPA = "fppa", -- nom de l'item acces au test psyco
	psycopass = "accestir" -- nom de l'item acces au test pratique
}

-- Message interactif 
Cweapon_licence.interaction = {
	bouton = {
		--Menu Acceuil
		Menu = {
			--Titre et sous titre 
			Titre = "~r~AMMU-NATION", 
			sublabel = "~b~Acceuil",	
			sblUn_separator = "~y~↓ ~b~Votre réponse ~y~↓";

			--sous titre Menu question
			repUn = "Oui, payer l'acces au test pour le PPA",
			repDeux = "Non, ne rien faire et partir"
		},
		MenuLSPD = {
			--Titre et sous titre 
			Titre = "~b~LSPD", 
			sublabel = "~b~Archives",	
			separatorLSPD = "~b~Bienvenue ~s~",

			separatorVPPA = "\nAucune personne(s) ne détient le ~b~PPA",

		},
	},
	-- Message d'acceuil
	acceuil = {
		[1] = "~r~[Gérant]~s~ Bonjour que puis-je faire pour vous",
		[2] = "~b~[Vous]~s~ Je souhaite passer le ppa, comment dois-je faire ? svp",
		[3] = "~r~[Gérant]~s~ Vous devez d'abord payer l'acces au test qui est de ~g~"..Cweapon_licence.price.." $",
		[4] = "~r~[Gérant]~s~ Ensuite vous pourrais passer le test psycologique aupres de ma collegue,",
		[5] = "~r~[Gérant]~s~ elle ce trouve devant le tableau dans la salle de cours .",
		[6] = "~r~[Gérant]~s~ Puis après il y a le test pratique .",
		[7] = "~r~[Gérant]~s~ Il ce passe au stand de tir .",
		[8] = "~r~[Gérant]~s~ Voulez-vous payez l'acces au test du ~b~PPA ~s~?",
		[9] = "~b~[Vous]~s~ Très bien je vous remercie, bonne journée MR .",
		[10] = "~r~[Gérant]~s~ Je vous en prie, bonne journée à vous également !",
		[11] = "~r~[Gérant]~s~ Désoler mais vous faite partie de la liste noir  .",
		[12] = "~r~[Gérant]~s~ Je ne peux donc pas vous aider , bonne journée !",
	}
}

-- Position Markers
Cweapon_licence.pos = {
	acceuilPPA = {
		position = {x = 20.34, y = -1106.06, z = 29.8} -- point interaction acceuil
	},

	testpsyco = {
		position = {x = 13.71, y = -1109.81, z = 29.79} -- point interaction psyco test
	},

	testtir = {
		position = {x = 15.06, y = -1098.65, z = 29.79} -- point interaction stand de tir
	},

	accesLSPD = {
		position = {x = 4.689553, y = -1106.46, z = 29.797} -- point interaction LSPD
	},

	-- position des mannequins au stand de tir
	pedtirppa = {
		[1] = {
			positionUn = {x = 11.83999, y = -1088.36, z = 28.845, h = 161.92},
			positionDeux = {x = 12.19341, y = -1083.57, z = 28.797, h = 154.58},
			positionTrois = {x = 14.98654, y = -1079.94, z = 28.845, h = 161.71},
			positionQuatre = {x = 14.95662, y = -1075.62, z = 28.797, h = 153.85},
			positionCinq = {x = 17.66911, y = -1072.51, z = 28.797, h = 158.55},
			positionSix = {x = 17.64770, y = -1069.12, z = 28.845, h = 176.95},
		},
		[2] = {
			positionUn = {x = 13.80130, y = -1089.26, z = 28.845, h = 164.12},
			positionDeux = {x = 13.98968, y = -1085.70, z = 28.9, h = 159.48},
			positionTrois = {x = 16.75712, y = -1077.86, z = 28.797, h = 154.27},
			positionQuatre = {x = 17.29800, y = -1076.03, z = 28.797, h = 170.32},
			positionCinq = {x = 17.28654, y = -1079.74, z = 28.797, h = 153.51},
			positionSix = {x = 19.94785, y = -1069.74, z = 28.845, h = 169.27},
		},
		[3] = {
			positionUn = {x = 15.73688, y = -1089.77, z = 28.845, h = 155.92},
			positionDeux = {x = 15.91337, y = -1085.91, z = 28.797, h = 162.43},
			positionTrois = {x = 19.02970, y = -1081.01, z = 28.797, h = 155.36},
			positionQuatre = {x = 19.32555, y = -1076.58, z = 28.797, h = 154.85},
			positionCinq = {x = 21.72465, y = -1073.80, z = 28.797, h = 150.57},
			positionSix = {x = 21.69250, y = -1070.60, z = 28.845, h = 161.84},
		},
		[4] = {
			positionUn = {x = 17.67, y = -1090.43, z = 28.85, h = 159.37},
			positionDeux = {x = 17.9, y = -1086.65, z = 28.8, h = 162.34},
			positionTrois = {x = 20.08, y = -1083.63, z = 28.8, h = 163.82},
			positionQuatre = {x = 20.07, y = -1080.53, z = 28.8, h = 158.37},
			positionCinq = {x = 22.45, y = -1077.43, z = 28.8, h = 157.14},
			positionSix = {x = 22.66, y = -1073.2, z = 28.8, h = 162.59},
		},
	},
}

-- espace entre les questions et les réponse (a utiliser si votre question est longue !)
Cweapon_licence.espace = {
	questionUN = true,
	questionDeux = true,
	questionTrois = false,
	questionQuatre = false,
	questionCinq = true,
}

-- Questionnaire Psycologique resultat/5
Cweapon_licence.quest = {

	-----
	--1--
	-----
	questionun = {
		questone = "~y~Que faire\n si la superette où vous vous trouver ce fait braquer ?", -----question numéros 1
		repquestone = "~p~1 :~r~ je me cache et appelle la police !", ----- réponse numéros 1 
		descrepquestone = "Au secours !!!!", ----- indice cacher numéros 1
		resultQRone = true, -- true = Bonne réponse, false = mauvaise réponse

		repquestdeux = "~p~2 :~r~ Je joue le super hero et tire sur les braqueur !", ----- réponse numéros 2
		descrepquestdeux = "Personne ne peux me stopper....", ----- indice cacher numéros 2
		resultQRdeux = false, -- true = Bonne réponse, false = mauvaise réponse

		repquesttrois = "~p~3 :~r~ Je propose aux braqueurs de tuer l'épicier !", ----- réponse numéros 3
		descrepquesttrois = "Il faut eviter d'avoir des témoins....",  ----- indice cacher numéros 3
		resultQRtrois = false, -- true = Bonne réponse, false = mauvaise réponse
	},

	-----
	--2--
	-----
	questiondeux = {
		questtwo = "~y~Une personne arrive vers vous avec un couteau\n~y~Vous avez votre arme à feu sur vous que faites vous ?", -----question numéros 2
		repquesttwo = "~p~1 :~r~ Je dégaine mon arme et lui dit de lâcher son arme !", ----- réponse numéros 1 
		descrepquesttwo = "Fait gafe j'ai un flingue poto !!!!", ----- indice cacher numéros 1
		resultQRtwo = false, -- true = Bonne réponse, false = mauvaise réponse

		repquestdeux = "~p~2 :~r~ Je cours le plus vite possible !!", ----- réponse numéros 2
		descrepquestdeux = "Putain les flics sont ou ....?", ----- indice cacher numéros 2
		resultQRdeux = false, -- true = Bonne réponse, false = mauvaise réponse

		repquesttrois = "~p~3 :~r~ J'apelle la police et quitte pas la personne des yeux !", ----- réponse numéros 3
		descrepquesttrois = "Allo Police !", ----- indice cacher numéros 3
		resultQRtrois = true, -- true = Bonne réponse, false = mauvaise réponse
	},

	-----
	--3--
	-----
	questiontrois = {
		questthree = "~y~Pouvez vous tirer en l'air en plein centre ville ?", -----question numéros 3
		repquestthree = "~p~1 :~r~ oui ,si c'est pour faire des tirs de sommation !", ----- réponse numéros 1 
		descrepquestthree = "Je me fait tirer dessus au secours !!!!", ----- indice cacher numéros 1
		resultQRthree = true, -- true = Bonne réponse, false = mauvaise réponse

		repquestdeux = "~p~2 :~r~ oui, pour le feux d'artifice tout les petards son permis !", ----- réponse numéros 2
		descrepquestdeux = "personne ne peux me stopper ....", ----- indice cacher numéros 2
		resultQRdeux = false, -- true = Bonne réponse, false = mauvaise réponse

		repquesttrois = "~p~3 :~r~ oui, j'adore viser les pigeons !", ----- réponse numéros 3
		descrepquesttrois = "je veux pas de merde sur mon capot ....", ----- indice cacher numéros 3
		resultQRtrois = false, -- true = Bonne réponse, false = mauvaise réponse
	},

	-----
	--4--
	-----
	questionquatre = {
		questfour = "~y~Ai-je le droit de porter un pistolet illegal avec mon PPA ?",
		repquestfour = "~p~1 :~r~ oui, c'est un permis de port d'arme !",
		descrepquestfour = "Je peux porter les armes que je veux !",
		resultQRfour = false, -- true = Bonne réponse, false = mauvaise réponse

		repquestdeux = "~p~2 :~r~ non, seulement si on me la donne !",
		descrepquestdeux = "Quoi ?! Donner c'est donner ok ...",
		resultQRdeux = false, -- true = Bonne réponse, false = mauvaise réponse

		repquesttrois = "~p~3 :~r~ non, sa reste illegal !",
		descrepquesttrois = "Je veux pas d'ennuie moi !",
		resultQRrois = true, -- true = Bonne réponse, false = mauvaise réponse
	},

	-----
	--5--
	-----
	questioncinq = {
		questfive = "~y~Un enfant se fait kidnappé devant vous !\n Que Faite Vous ?",
		repquestfive = "~p~1 :~r~ je sort mon arme et tire sur le kidnappeur!",
		descrepquestfive = "Je vais le fumer !",
		resultQRfive = false, -- true = Bonne réponse, false = mauvaise réponse

		repquestdeux = "~p~2 :~r~ je cours en appelant à l'aide !",
		descrepquestdeux = "Au secours, un enfant c'est fait enlever !",
		resultQRdeux = false, -- true = Bonne réponse, false = mauvaise réponse

		repquesttrois = "~p~3 :~r~ j'appel la police discretement !",
		descrepquesttrois = "je suis pas un super héros,\nmais une bonne personne au moins!",
		resultQRtrois = true, -- true = Bonne réponse, false = mauvaise réponse
	},

}
