ESX = nil

local function isWebhookSet(val)
    return val ~= nil and val ~= ""
end
local pass = true

local iPlayers = nil
-- MySQL.ready(function()
--     MySQL.Async.fetchAll('SELECT * FROM users', {}, function(result)
--         for k,v in pairs(result) do
--             iPlayers = {}
--             for i=1,k ,1 do
--                 table.insert(iPlayers,{
--                     id = v.identifier,
--                     name = v.lastname,
--                     prenom = v.firstname,
--                     dob = v.dateofbirth
--                 })
--             end
--         end
--     end)
-- end)

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local webhookColors = {
    ["red"] = 16711680,
    ["green"] = 56108,
    ["grey"] = 8421504,
    ["orange"] = 16744192
}

function sendWebhook(message,color,url)
    local DiscordWebHook = url
    local embeds = {
        {
            ["title"]= message,
            ["type"]="rich",
            ["color"] = webhookColors[color],
            ["footer"]=  {
                ["text"]= "Ammunation",
            },
        }
    }
    PerformHttpRequest(DiscordWebHook, function(err, text, headers) end, 'POST', json.encode({ username = "Ammunation",embeds = embeds}), { ['Content-Type'] = 'application/json' })
end

RegisterNetEvent("aWeapon_Licence:accesstandtir")
AddEventHandler("aWeapon_Licence:accesstandtir", function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local xName = xPlayer.getName()

    xPlayer.addInventoryItem("accestir", 1)

    if isWebhookSet(Cweapon_licence.webhook.onPPA) then
        sendWebhook(("Information PPA : \n\nIdentité : "..xName.." (Nom Steam)\nDéscription : \nCette personne vien de réussir le test psycologique !"), "orange", Cweapon_licence.webhook.onPPA)
    end

end)

RegisterNetEvent("aweapon_licence:tchektestpsyco")
AddEventHandler("aweapon_licence:tchektestpsyco", function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local item = Cweapon_licence.Item.psycopass
    local nbitem = xPlayer.getInventoryItem(item).count

    if nbitem > 0 then
        xPlayer.removeInventoryItem(item, 1)
        TriggerClientEvent("aweapon_licence:lancementppatir", source)
    else
        TriggerClientEvent('esx:showNotification', source, "~r~Vous devez d'abord passer le test psycologique !")
    end
end)

RegisterNetEvent("aWeapon_Licence:givelicence")
AddEventHandler("aWeapon_Licence:givelicence", function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local xName = xPlayer.getName()
    local idPlayer = json.encode(xPlayer.identifier)
    -- print(json.encode(xName))

    MySQL.Async.execute('INSERT INTO user_licenses (`type`, `owner`) VALUES (@type, @owner)', {
        ['@type'] = 'weapon',
        ['@owner'] = xPlayer.identifier
    })


    MySQL.Async.fetchAll('SELECT * FROM users', {}, function(result)
        infoppaOwner = {}
        for k,v in pairs(result) do
            -- print(k, json.encode(v))
            if v.identifier == xPlayer.identifier then
                local id = v.identifier
                local name = v.name
                local nom = v.lastname 
                local prenom = v.firstname
                local dob = v.dateofbirth
                MySQL.Async.execute('INSERT INTO aweapon_info (`identifier`, `nom`, `prenom`, `dob`, `pass`) VALUES (@identifier, @nom, @prenom, @dob, @pass)', {
                    ['@identifier'] = id,
                    ['@nom'] = nom,
                    ['@prenom'] = prenom,
                    ['@dob'] = dob,
                    ['@pass'] = 0
                })
            end
        end
    end)

    TriggerEvent("aWeapon_Licence:infodiscord", xName)
end)

RegisterServerEvent("aWeapon_Licence:infodiscord")
AddEventHandler("aWeapon_Licence:infodiscord", function(xName)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local NomDuMec = xName

	if isWebhookSet(Cweapon_licence.webhook.onPPA) then
		sendWebhook(("Information PPA : \n\nIdentité : "..NomDuMec.." (Nom Steam)\nDéscription : \nCette personne vien de reussir le PPA"), "green", Cweapon_licence.webhook.onPPA)
	end

end)

local infoperm = nil

ESX.RegisterServerCallback("aWeapon:getPlayerJob", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM users', {}, function(result)

        for k,v in pairs(result) do
            if xPlayer.identifier == v.owner then
                return cb(true)
            else
                print('test')
                return cb(false)
            end
        end
    end)
end)

local infoppaOwner = nil
local Nowners = nil 
local testaction


ESX.RegisterServerCallback("aWeapon:GetPlayersLicences", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
  
    MySQL.Async.fetchAll('SELECT * FROM aweapon_info', {}, function(result)
        infoppaOwner = {}

        if result then
            for k,v in pairs(result) do 
                table.insert(infoppaOwner,{
                    id = v.identifier,
                    nom = v.nom,
                    prenom = v.prenom,
                    dob = v.dob,
                    pass = v.pass
                })
            end
        else
        end
    end)
    testaction = json.encode(infoppaOwner)
    return cb(infoppaOwner)
end)

RegisterNetEvent("aWeapon_Licence:deletelicence")
AddEventHandler("aWeapon_Licence:deletelicence", function(identifier)
    print(json.encode(xPlayer))
    MySQL.Async.fetchAll('SELECT * FROM user_licenses', {}, function(result)
        for k,v in pairs(result) do
            -- print(json.encode(v))
            if v.owner == identifier then
                print("delete")
                local id = v.id
                local type = v.type
                local identifier = v.owner
                MySQL.Async.execute('DELETE FROM user_licenses WHERE id = @id',{
                    ['@id'] = v.id
                })
            end
        end
    end)
    MySQL.Async.fetchAll('SELECT * FROM aweapon_info', {}, function(result)
        for k,v in pairs(result) do
            -- print(k,json.encode(v))
            if v.identifier == identifier then
                print("delete")
                local id = v.identifier
                -- MySQL.Async.execute("UPDATE aweapon_info SET pass = @pass WHERE identifier = @identifier", {
                --     ["@identifier"] = v.identifier, 
                --     ["@pass"] = 1
                -- })
                MySQL.Async.execute('DELETE FROM aweapon_info WHERE identifier = @identifier',{
                    ['@identifier'] = v.identifier
                })
            end
        end
    end)
end)

-- ESX.RegisterServerCallback("aWeapon:GetPassAccess", function(source, cb)
--     local xPlayer = ESX.GetPlayerFromId(source)
--     MySQL.Async.fetchAll('SELECT * FROM aweapon_info', {}, function(result)
--         for k,v in pairs(result) do
--             if xPlayer.identifier == v.identifier then
--                 if v.pass == 0 then
--                     return cb(true)
--                 else
--                     return cb(false)
--                 end
--             else
--                 return cb(true)
--             end
--         end
--     end)
-- end)

RegisterNetEvent("aWeapon_Licence:antipass")
AddEventHandler("aWeapon_Licence:antipass", function(identifier)
    
    MySQL.Async.fetchAll('SELECT * FROM aweapon_info', {}, function(result)
        for k,v in pairs(result) do
            print(k,json.encode(v))
            if v.identifier == identifier then

                MySQL.Async.execute("UPDATE aweapon_info SET pass = @pass WHERE identifier = @identifier", {
                    ["@identifier"] = v.identifier, 
                    ["@pass"] = 1
                })
                
            end
        end
    end)
end)

RegisterNetEvent("aWeapon_Licence:deleteantipass")
AddEventHandler("aWeapon_Licence:deleteantipass", function(identifier)
    
    MySQL.Async.fetchAll('SELECT * FROM aweapon_info', {}, function(result)
        for k,v in pairs(result) do
            print(k,json.encode(v))
            if v.identifier == identifier then

                MySQL.Async.execute("UPDATE aweapon_info SET pass = @pass WHERE identifier = @identifier", {
                    ["@identifier"] = v.identifier, 
                    ["@pass"] = 0
                })
                
            end
        end
    end)
end)

RegisterNetEvent("aWeapon_Licence:PlayerPayAccess")
AddEventHandler("aWeapon_Licence:PlayerPayAccess", function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local xName = xPlayer.getName()
    MySQL.Async.fetchAll('SELECT * FROM aweapon_info', {}, function(result)
        for k,v in pairs(result) do
            if v.identifier == xPlayer.identifier then
                local nbpass = v.pass
                print(nbpass)
                if nbpass == '0' then
                    print("nbpas  = 0")
                    if xPlayer.getMoney() > Cweapon_licence.price then
                        xPlayer.removeMoney(Cweapon_licence.price)
                        xPlayer.addInventoryItem(Cweapon_licence.Item.paiementPPA, 1)

                        TriggerClientEvent('esx:showNotification', _source, "~g~Vous pouvez maintenant passer le test psycologique !")

                        if isWebhookSet(Cweapon_licence.webhook.onPPA) then
                            sendWebhook(("Information PPA : \n\nIdentité : "..xName.." (Nom Steam)\nDéscription : \nCette personne vien de payer l'acces au test PPA d'une valeur de "..Cweapon_licence.price.." $"), "green", Cweapon_licence.webhook.onPPA)
                        end

                    else
                        TriggerClientEvent('esx:showNotification', _source, "~r~Vous n'avez pas asser d'argent !")
                    end
                elseif v.pass == '1' then
                    print("nbpas  = 1")
                    TriggerClientEvent('esx:showNotification', _source, "~r~Vous êtes interdit d'acces !")
                end
            else
                print("nbpas  = 3")
                if xPlayer.getMoney() > Cweapon_licence.price then
                    xPlayer.removeMoney(Cweapon_licence.price)
                    xPlayer.addInventoryItem(Cweapon_licence.Item.paiementPPA, 1)
                    TriggerClientEvent('esx:showNotification', _source, "~g~Vous pouvez maintenant passer le test psycologique !")

                    if isWebhookSet(Cweapon_licence.webhook.onPPA) then
                        sendWebhook(("Information PPA : \n\nIdentité : "..xName.." (Nom Steam)\nDéscription : \nCette personne vien de payer l'acces au test PPA d'une valeur de "..Cweapon_licence.price.." $"), "green", Cweapon_licence.webhook.onPPA)
                    end

                else
                    TriggerClientEvent('esx:showNotification', _source, "~r~Vous n'avez pas asser d'argent !")
                end
            end
        end
    end)

end)

RegisterNetEvent("aWeapon_Licence:PlayerPsyAccess")
AddEventHandler("aWeapon_Licence:PlayerPsyAccess", function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(source)
	local item = Cweapon_licence.Item.paiementPPA
    local nbitem = xPlayer.getInventoryItem(item).count

    if nbitem >= 1 then
        xPlayer.removeInventoryItem(item, 1)
        TriggerClientEvent('aWeapon_Licence:PlayerPsyAccessOk', source)
    else
        TriggerClientEvent('esx:showNotification', source, "~r~Vous n'avez pas payer l'acces aux test PPA !")
    end
end)

RegisterNetEvent("aWeapon_Licence:PlayerLoosePsy")
AddEventHandler("aWeapon_Licence:PlayerLoosePsy", function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local xName = xPlayer.getName()

    if isWebhookSet(Cweapon_licence.webhook.onPPA) then
        sendWebhook(("Information PPA : \n\nIdentité : "..xName.." (Nom Steam)\nDéscription : \nCette personne vien de louper le test psycologique"), "red", Cweapon_licence.webhook.onPPA)
    end
end)

RegisterNetEvent("aWeapon_Licence:PlayerLooseTir")
AddEventHandler("aWeapon_Licence:PlayerLooseTir", function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local xName = xPlayer.getName()

    if isWebhookSet(Cweapon_licence.webhook.onPPA) then
        sendWebhook(("Information PPA : \n\nIdentité : "..xName.." (Nom Steam)\nDéscription : \nCette personne vien de louper le test pratique"), "red", Cweapon_licence.webhook.onPPA)
    end
end)

RegisterNetEvent("aWeapon_Licence:GiveWeaponTest")
AddEventHandler("aWeapon_Licence:GiveWeaponTest", function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local Iweapon = Cweapon_licence.Item.weaponName
    local Bullet = Cweapon_licence.Item.bulletName
    local nbBullet = Cweapon_licence.Item.bulletNumber

    if Cweapon_licence.useWeaponItem then
        xPlayer.addInventoryItem(Iweapon, 1)
        xPlayer.addInventoryItem(Bullet, nbBullet)
    else
        xPlayer.addWeapon(Iweapon, nbBullet)
    end
    
end)

RegisterNetEvent("aWeapon_Licence:RemoveWeaponTest")
AddEventHandler("aWeapon_Licence:RemoveWeaponTest", function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local item = Cweapon_licence.Item.weaponName
    local nbitem = xPlayer.getInventoryItem(item).count

    if Cweapon_licence.useWeaponItem then
        if nbitem >= 1 then
            xPlayer.removeInventoryItem(item, 1)
        end
    else
        if nbitem >= 1 then
            xPlayer.removeWeapon(item)
        end
    end
end)