CREATE TABLE `aweapon_info` (
  `id` int(11) NOT NULL,
  `identifier` longtext DEFAULT NULL,
  `nom` longtext DEFAULT NULL,
  `prenom` longtext DEFAULT NULL,
  `dob` longtext DEFAULT NULL,
  `pass` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `aweapon_info` (`id`, `identifier`, `nom`, `prenom`, `dob`, `pass`) VALUES
(135, 'fsqfqZQFgdfs<ghq', 'Charles', 'Henry', '1994/04/11', '0'),
(137, 'gfwgrwqghgfsw', 'Agora', 'Jyben', '1991/06/08', '0');


--
-- Index pour la table `aweapon_info`
--
ALTER TABLE `aweapon_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `aweapon_info`
--
ALTER TABLE `aweapon_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;
COMMIT;


-----------------------
---------WEIGHT--------
-----------------------


INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
('combatpistol', 'Pistolet de combat', 1, 0, 1),
('pistol_ammo', 'Balle de pistolet', -1, 0, 1),
('fppa', 'Reçu paiement PPA', 1, 0, 1),
('accestir', 'Card Stand PPA', 1, 0, 1);



-----------------------
---------LIMIT---------
-----------------------


INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
('combatpistol', 'Pistolet de combat', 50, 0, 1),
('pistol_ammo', 'Balle de pistolet', 25, 0, 1),
('fppa', 'Reçu paiement PPA', 25, 0, 1),
('accestir', 'Card Stand PPA', 25, 0, 1);